# 모두의 화살촉 — Play 스토어 등록 문구

- 패키지명: `com.moduseries.arrowhead` · 퍼블리셔: 모두의시리즈 · 카테고리: 게임 > 캐주얼(또는 아케이드)
- AAB: `releases/arrowhead-v1c2.aab` (versionCode 2 / versionName 1.1, 서명됨, AdMob 포함)
- 서명 키: `C:\dev\keystores\arrowhead-upload.jks` (alias `arrowhead`) — ⚠️ repo 커밋 금지, 백업 필수
- 아이콘 512: `store-assets/icon-512.png` · 피처: `store-assets/feature-1024x500.png` · 스크린샷: `store-assets/shot*.png`
- 개인정보처리방침 URL: `https://seungiljang.github.io/games/tuho-privacy.html`
- 빌드: OTA형(앱이 seungiljang.github.io/games/tuho.html 로드, 오프라인 폴백 내장) → 게임 수정은 games 레포 푸시로 반영
- ⚠️ 광고: AdMob 배너·전면·리워드 (현재 테스트ID, 출시 전 실ID 교체). 데이터안전성: 광고식별자 "예"·개인정보 "아니오"
- 빌드 환경: JDK21 + `C:\dev\android-sdk` + gradlew bundleRelease

---

## 🇰🇷 한국어

### 앱 이름 (최대 30자)
모두의 화살촉

### 간단한 설명 (최대 80자)
화살을 던져 항아리에 쏙! 각도·힘 2탭으로 즐기는 전통놀이 투호 🏹

### 자세한 설명 (최대 4000자)
◆ 모두의 화살촉 ◆
화살을 던져 항아리에 넣는 우리 전통놀이 '투호(投壺)'를 한 손으로 즐겨요.

① 탭해서 각도를 멈추고 → ② 탭해서 힘을 멈추면, 화살이 포물선을 그리며 날아가요. 항아리 입구에 쏙 들어가면 성공! 한가운데로 넣으면 '완벽' 2배 점수!

단계가 오를수록 항아리는 멀어지고 입구는 좁아지고, 바람까지 불어와요. 바람과 거리를 읽어 '한 끗'을 맞추는 손맛이 일품이에요.

■ 이렇게 즐겨요
· 각도탭 → 힘탭, 단 2번의 탭으로 발사
· 예측 조준선으로 궤적 미리보기
· 완벽 명중(한가운데) 2배 점수 + 연속 콤보
· 단계마다 멀어지는 거리·좁아지는 입구·바람
· 목숨 3개 — 신중하게! 최고 점수에 도전
· 석양 노을 배경의 차분하고 예쁜 전통 분위기

■ 이런 분께
· 짧고 감각적인 타이밍 게임을 찾는 분
· 전통놀이의 정겨운 손맛을 좋아하는 분
· 자투리 시간에 최고 점수 경신하고 싶은 분

지금 바로 화살을 던져보세요! 🏹🏺

* 가볍게 즐기는 캐주얼 전통놀이 게임이에요.

---

## 🇺🇸 English

### App name (max 30)
Tuho: Arrow Toss

### Short description (max 80)
Toss arrows into the pot! A 2-tap traditional Korean aiming game 🏹

### Full description (max 4000)
◆ Tuho: Arrow Toss ◆
Enjoy the Korean traditional game "Tuho" — toss arrows into a pot — with one hand.

① Tap to lock the angle → ② tap to lock the power, and your arrow flies in an arc. Land it right in the pot's mouth to score! Nail the dead center for a PERFECT 2x!

As you climb stages, the pot moves farther, the mouth narrows, and the wind picks up. Read the wind and distance to nail that razor-thin shot.

■ How to play
· Two taps — angle, then power
· Preview your arc with the aim guide
· PERFECT center hits score double + build combos
· Farther pots, narrower mouths, and wind each stage
· 3 lives — aim carefully and chase your best score
· Calm, pretty sunset setting

A relaxing casual arcade of a Korean traditional game.

Toss your arrow now! 🏹🏺

---

## 📋 Play Console 릴리스 노트 (복사해서 붙여넣기)

```
[한국어]
모두의 화살촉 첫 출시! 🏹
· 각도탭 → 힘탭 2탭으로 화살 던지기
· 완벽 명중 2배 + 연속 콤보
· 단계마다 거리·입구·바람 변화
· 목숨 3개 + 최고점수 도전
· 일시정지·음소거, 광고 없음
전통놀이 투호를 한 손으로, 지금 바로!

[English]
Tuho: Arrow Toss is here! 🏹
· Two taps — angle then power
· PERFECT center hits score 2x + combos
· Distance, pot mouth & wind change each stage
· 3 lives + high-score chase
· Pause/mute, no ads
Play the Korean classic one-handed!
```
